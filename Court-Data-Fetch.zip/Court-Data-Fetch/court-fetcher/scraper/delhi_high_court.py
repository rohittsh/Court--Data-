
from playwright.sync_api import sync_playwright

def fetch_case_data(case_type, case_number, year):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        try:
            page.goto("https://delhihighcourt.nic.in/case.asp")

            data = {
                "party_names": "A vs B",
                "filing_date": "2022-01-01",
                "next_hearing": "2025-08-20",
                "pdf_link": "https://example.com/latest_order.pdf"
            }
            html = page.content()
            return data, html
        except Exception as e:
            return {"error": str(e)}, ""
        finally:
            browser.close()
