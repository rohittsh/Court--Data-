
from flask import Flask, render_template, request
from scraper.delhi_high_court import fetch_case_data
from models.db import insert_query

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/fetch', methods=['POST'])
def fetch():
    case_type = request.form['case_type']
    case_number = request.form['case_number']
    filing_year = request.form['filing_year']

    data, raw_html = fetch_case_data(case_type, case_number, filing_year)

    insert_query(case_type, case_number, filing_year, raw_html)

    if data.get("error"):
        return f"<h3>Error: {data['error']}</h3>"

    return render_template('result.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
