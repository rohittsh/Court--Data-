
# Court Data Fetcher

## Description
Fetches metadata and latest orders for Delhi High Court cases.

## Setup

```bash
pip install -r requirements.txt
playwright install
python app.py
```

## CAPTCHA Strategy
Currently manual or AI-based service integration (TBD).

## Court Targeted
Delhi High Court (https://delhihighcourt.nic.in/)
